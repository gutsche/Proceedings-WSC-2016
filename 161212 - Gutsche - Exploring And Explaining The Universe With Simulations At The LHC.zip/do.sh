pdflatex wsc16paper && bibtex wsc16paper && pdflatex wsc16paper && pdflatex wsc16paper && open wsc16paper.pdf
